/*
 * DownloadServlet.java
 *
 */

package control;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;


/**
 *
 * @author  jongmin
 * @version
 */
public class DownloadServlet extends HttpServlet {
    
    /** Initializes the servlet.
     * @param config
     * @throws javax.servlet.ServletException
     */
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        setDirectory();
    }
    
    private final String OSName = System.getProperty("os.name").toLowerCase();
    String downloadDir;
    /**
     * Setting Mail Directory.
     */
    private void setDirectory() {
        if(OSName.contains("win")) {
            //window 운영체제
            downloadDir = "C:/temp/download/";
        }else if(OSName.contains("nix") 
                || OSName.contains("nux")|| OSName.contains("aix")) {
            //unix 운영체제들
            downloadDir = "/var/spool/webmail/download/";
        }
    }
    
    /** Destroys the servlet.
     */
    @Override
    public void destroy() {
        
    }
    
    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws javax.servlet.ServletException
     * @throws java.io.IOException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("application/octet-stream");
        
        ServletOutputStream sos = response.getOutputStream();
        
        request.setCharacterEncoding("euc-kr");
        String fileName = new String(request.getParameter("filename").getBytes("8859_1"), "euc-kr");

        fileName = fileName.replaceAll(" ", "+");
        String userid = request.getParameter("userid");
        //String fileName = URLDecoder.decode(request.getParameter("filename"), "utf-8");
        


        //String downloadDir = "/var/spool/webmail/download/";

        // �������� ȯ�� ����
        String downloadDir = "C:/temp/download/";
        // LJM 090430 : �����ؾ� �� �κ� - end   ------------------

        response.setHeader("Content-DIsposition", "attachment; filename=" + fileName + ";");
        
        File f;
        f = new File(downloadDir + userid + "/" + fileName);
        byte[] b = new byte[(int)f.length()];
        FileInputStream fis = new FileInputStream(f);
        int read = fis.read(b);

        // �ٿ�ε�
        sos.write(b);
        sos.flush();
        
        // �ٿ�ε��� ���� ����
        //f.delete();
        
        sos.close();
    }
    
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws javax.servlet.ServletException
     * @throws java.io.IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws javax.servlet.ServletException
     * @throws java.io.IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
}
