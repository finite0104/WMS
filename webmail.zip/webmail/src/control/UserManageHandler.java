/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ���
 */
public class UserManageHandler extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet UserManageHandler</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet UserManageHandler at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {
            out.close();
        }
    }
    

    
private void addUser(HttpServletRequest request,
                        HttpServletResponse response, PrintWriter out) {
     String server = "127.0.0.1";
     int port = 4555;
     try {
         UserAdminAgent agent = new UserAdminAgent(Server, port);
         
         String userid = request.getParameter("id");
         String password = request.getParameter("password");
         
         out.println("userid = " + userid + "<br>");
         out.println("password = " + password + "<br>");
         out.flush();
         
         if (agent.addUser(userid, password))
             out.println(getUserAddSuccessPopUp());
     } else {
             out.println(getUserAddFailurePopUp());
             }
     out.flush();
 }catch (Exception ex) {
    out.println("�ý��� ���ӿ� �����߽��ϴ�.");
}

    private boolean getUserAddSuccessPopUp() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        String alertMessage = "����� �߰��� �����Ͽ����ϴ�.";
        StringBuilder successPopup = new StringBuilder();
        successPopup.append("<html>");
        successPopup.append("<head>");
        successPopup.append("<title> Result of adding users </title>");
        successPopup.append("<link type=\"text/css\" rel=\"stylesheet\" href=\"css/index.css\" />");
        successPopup.append("</head>");
        successPopup.append("<body onload=\"goMainMenu()\">");
        successPopup.append("<script type=\"text/javascript\">");
        successPopup.append("function goMainMenu(){");
        successPopup.append("alert(\"");
        successPopup.append(alertMessage);
        successPopup.append("\");");
        successPopup.append("window.location = \"admin_menu.jsp\";");
        successPopup.append("} </script>");
        successPopup.append("</body></html>");
        return successPopup.toString();   
    }
}
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    } 
