package control;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ���
 */
public class CommandType {
        public final static int ADD_USER_MENU = 3;
        public final static int DELETE_USER_MENU = 4;
        
        public final static int SEND_MAIL_COMMAND = 5;
        public final static int DELETE_MAIL_COMMAND = 6;
        public final static int DOWNLOAD_COMMAND = 7;
        
        public final static int ADD_USER_COMMAND = 8;
        public final static int DELETE_USER_COMMAND = 9;
        
        public final static int LOGIN = 91;
        public final static int LOGOUT= 92;
    
}
